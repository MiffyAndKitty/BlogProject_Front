import './App.css';
import Add from './Add';

function App() {
  return (
    <Add></Add>
    
  );
}

export default App;
